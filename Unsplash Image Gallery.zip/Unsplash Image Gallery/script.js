const accessKey = 'qA5znZvKNYatDg0PycC2b4Q-hdSc8Pertdn-kWPLMU0';
const searchButton = document.getElementById('search-button');
const searchInput = document.getElementById('search-input');
const imageGallery = document.getElementById('image-gallery');
const loadMoreButton = document.getElementById('load-more-button');

let currentPage = 1;
let currentQuery = '';

searchButton.addEventListener('click', () => {
    currentQuery = searchInput.value;
    currentPage = 1;
    if (currentQuery) {
        fetchImages(currentQuery, currentPage);
    }
});

searchInput.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
        currentQuery = searchInput.value;
        currentPage = 1;
        if (currentQuery) {
            fetchImages(currentQuery, currentPage);
        }
    }
});

loadMoreButton.addEventListener('click', () => {
    currentPage++;
    fetchImages(currentQuery, currentPage);
});

async function fetchImages(query = '', page = 1) {
    try {
        const url = query ?
            `https://api.unsplash.com/search/photos?query=${query}&page=${page}&client_id=${accessKey}` :
            `https://api.unsplash.com/photos?page=${page}&client_id=${accessKey}`;

        const response = await fetch(url);
        const data = await response.json();
        const results = query ? data.results : data;

        if (page === 1) {
            imageGallery.innerHTML = '';
        }

        results.forEach(photo => {
            const imgElement = document.createElement('img');
            imgElement.src = photo.urls.small;
            imgElement.alt = photo.alt_description || 'Unsplash Image';
            imageGallery.appendChild(imgElement);
        });
    } catch (error) {
        console.error('Error fetching images:', error);
    }
}

// Fetch initial set of images
fetchImages();